public class StudentManagement {
    public Student[] students = new Student[100];
    public int countStudent = 0;

    /**
     * Check same group.
     */
    public static boolean sameGroup(Student s1, Student s2) {
        if (s1.getGroup().equals(s2.getGroup())) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Add one Student.
     */
    public void addStudent(Student newStudent) {
        students[this.countStudent] = newStudent;
        this.countStudent++;
    }

    /**
     * Remove one Student.
     */
    public void removeStudent(String id) {
        for (int i = 0; i < this.countStudent; i++) {
            if (this.students[i].getId().equals(id)) {
                for (int j = i; j < this.countStudent - 1; j++) {
                    this.students[j] = this.students[j + 1];
                }
                this.countStudent--;
                break;
            }
        }
    }

    /**
     * Group Students.
     */
    public String studentsByGroup() {
        String ans = "";
        int[] check = new int[this.countStudent];
        for (int i = 0; i < this.countStudent; i++) {
            if (check[i] == 0) {
                check[i] = 1;
                ans += this.students[i].getGroup() + "\n";
                ans += this.students[i].getInfo() + "\n";
                for (int j = i + 1; j < this.countStudent; j++) {
                    if (this.students[j].getGroup().equals(this.students[i].getGroup())) {
                        ans += this.students[j].getInfo() + "\n";
                        check[j] = 1;
                    }
                }
            }
        }

        return ans;
    }
}
